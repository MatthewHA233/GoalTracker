export interface TaskSnapshot {
  taskNumber: number;
  taskTime: number;
  totalTime: number;
}